package com.example.sanchesnparcial2_v2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sanchesnparcial2_v2.adapter.GaleriaAdapter
import com.example.sanchesnparcial2_v2.adapter.ProductoAdapter
import com.example.sanchesnparcial2_v2.databinding.ActivityMainGaleriaBinding

class MainGaleria : AppCompatActivity() {

    private lateinit var binding: ActivityMainGaleriaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainGaleriaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initRecyclerView()
    }

    private fun initRecyclerView(){
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerGal)
        val manager = GridLayoutManager(this,2)
        recyclerView.layoutManager = manager

        recyclerView.adapter = GaleriaAdapter(GaleriaProvider.galeriaList) {
            onItemSelected(it)
        }
    }

    private fun onItemSelected(galeria: Galeria){
        Toast.makeText(this,galeria.nombreG,Toast.LENGTH_SHORT).show()
    }
}