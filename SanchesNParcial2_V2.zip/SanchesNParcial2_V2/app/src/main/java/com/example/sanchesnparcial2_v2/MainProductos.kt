package com.example.sanchesnparcial2_v2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sanchesnparcial2_v2.adapter.ProductoAdapter
import com.example.sanchesnparcial2_v2.databinding.ActivityMainProductosBinding

class MainProductos : AppCompatActivity() {

    private lateinit var binding: ActivityMainProductosBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainProductosBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initRecyclerView()
    }

    private fun initRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerProducto)
        val manager = LinearLayoutManager(this)
        recyclerView.layoutManager = manager

        recyclerView.adapter = ProductoAdapter(ProductoProvider.productoLst) {
            onItemSelected(it)
        }
    }

    private fun onItemSelected(producto: Producto) {
        Toast.makeText(this, producto.nombre, Toast.LENGTH_SHORT).show()
    }
}
