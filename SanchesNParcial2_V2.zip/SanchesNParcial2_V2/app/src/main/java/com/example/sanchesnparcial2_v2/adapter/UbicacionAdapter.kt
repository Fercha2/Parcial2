package com.example.sanchesnparcial2_v2.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.sanchesnparcial2_v2.R
import com.example.sanchesnparcial2_v2.Ubicacion


class UbicacionAdapter (private val ubicacionList: List<Ubicacion>, private val onClickListener: (Ubicacion) -> Unit) : RecyclerView.Adapter<UbicacionViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UbicacionViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return UbicacionViewHolder(layoutInflater.inflate(R.layout.item_ubi,parent,false))
    }

    override fun getItemCount(): Int =ubicacionList.size

    override fun onBindViewHolder(holder: UbicacionViewHolder, position: Int) {
        val item = ubicacionList[position]
        holder.render(item,onClickListener)
    }

}