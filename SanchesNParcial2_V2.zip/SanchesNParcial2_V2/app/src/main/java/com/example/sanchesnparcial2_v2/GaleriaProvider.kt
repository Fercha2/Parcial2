package com.example.sanchesnparcial2_v2

class GaleriaProvider {
    companion object{
        val galeriaList: List<Galeria>
            get()= listOf(
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/542/PY-5382_Hatsan-Zada_1688677863.jpg",
                    categoriaG = "Resorte",
                    nombreG = "Rifle Hatsan Zada 5.5 Mira 4x32"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/345/gamo-whisper-x-vampir.jpg",
                    categoriaG = "Resorte",
                    nombreG = "Rifle Gamo Delta Fox GT 5.5 Mira 4x20"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/334/DELTA_FOX_GT_1DE3.jpg",
                    categoriaG = "Resorte",
                    nombreG = "Rifle Gamo Whisper X Vampir 5.5 Mira 3-9x40"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/331/CARBON_STORM_1DE3.jpg",
                    categoriaG = "Resorte",
                    nombreG = "Rifle Gamo Carbon Storm 5.5 Mira 3-9x40"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/359/SYRIX_177_1DE7.jpg",
                    categoriaG = "NITRO PISTÓN",
                    nombreG = "Rifle Umarex Syrix 4.5 Mira 4x32"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/330/BONE_COLLECTOR_1DE5.jpg",
                    categoriaG = "Resorte",
                    nombreG = "Rifle Gamo Bone Collector 5.5 mira 3-9x40"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/543/PY-6117_Umarex-Prymex-177_1702574376.webp",
                    categoriaG = "NITRO PISTÓN",
                    nombreG = "Rifle Umarex Prymex 5.5 Mira 4x32"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/354/EMERGE_22.jpg",
                    categoriaG = "NITRO PISTÓN",
                    nombreG = "Rifle Umarex Emerge 5.5 Mira 4x32"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/344/j6fJtnFpUUMi72tB8LeGvCKTFTHbuNR59vN2lDc4.jpg",
                    categoriaG = "NITRO PISTÓN",
                    nombreG = "Rifle Gamo Shadow IGT 6.35 Mira 4x32"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/341/ROADSTER_10X_1DE5.jpg",
                    categoriaG = "NITRO PISTÓN",
                    nombreG = "Rifle Gamo Roadster 10X GEN 2 5.5 Mira 3-9x40"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/337/GMAGNUM_WHISPER_1250_1DE4.jpg",
                    categoriaG = "NITRO PISTÓN",
                    nombreG = "Rifle Gamo Gmagnum Whisper 1250 5.5 Mira 3-9x40"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/336/G-MAGNUM-IGT-MACH-1.jpg",
                    categoriaG = "NITRO PISTÓN",
                    nombreG = "Rifle Gamo Gmagnum 1250 5.5 Mira 3-9x40"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/329/BLACK_FUSION_1DE2.jpg",
                    categoriaG = "NITRO PISTÓN",
                    nombreG = "Rifle Gamo Black Fusion 5.5 Mira 3-9x40"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/369/Jd3oXsHd7ugh0OGTzMD2X5PuzpOOsiq35tdjUK9U.jpg",
                    categoriaG = "CO2 E INFANTILES",
                    nombreG = "Subfusil Umarex HK 416 Electrica"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/532/Crosman-DPMS-M4-SBR-Semi-Auto-CO2-Air-Rifle-Gallery-1.jpg",
                    categoriaG = "CO2 E INFANTILES",
                    nombreG = "Subfusil Crosman DPMS SBR CO2"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/533/08.jpg",
                    categoriaG = "CO2 E INFANTILES",
                    nombreG = "Subfusil Crosman AK01 CO2"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/355/RUGER_CO2_177_1DE10.jpg",
                    categoriaG = "CO2 E INFANTILES",
                    nombreG = "Rifle Umarex Ruger 4.5 Co2"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/353/APX_177_1DE7.jpg",
                    categoriaG = "CO2 E INFANTILES",
                    nombreG = "Rifle Umarex Apx 4.5 Mira 4x15 Kit"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/545/WhatsApp%20Image%202024-04-22%20at%205.01.27%20PM.jpeg",
                    categoriaG = "CO2 E INFANTILES",
                    nombreG = "Rifle Daysi Red Ryder 4.5 Camo"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/339/RED_RYDER_1DE1.jpg",
                    categoriaG = "CO2 E INFANTILES",
                    nombreG = "Rifle Daysi Red Ryder 4.5"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/544/992105-633.png",
                    categoriaG = "CO2 E INFANTILES",
                    nombreG = "Rifle Daysi Buck 4.5 Mod. 105"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/364/ORIGIN_22_PCP_1DE13.jpg",
                    categoriaG = "CALIBRE .22 MM",
                    nombreG = "Rifle Umarex Origin 5.5 PCP"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/361/GAUNTLET2_PCP_1DE6.jpg",
                    categoriaG = "CALIBRE .22 MM",
                    nombreG = "Rifle Umarex Gauntlet 2 PCP 5.5"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/398/prre.jpg",
                    categoriaG = "CALIBRE .22 MM",
                    nombreG = "Rifle Snowpeak PR900 5.5 PCP"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/393/SigSauer%20PCP%202.jpg",
                    categoriaG = "CALIBRE .22 MM",
                    nombreG = "Rifle Sig Sauer MXC Virtus PCP 5.5"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/395/COYOTE-BLACK-1.jpg",
                    categoriaG = "CALIBRE .22 MM",
                    nombreG = "Rifle Gamo Coyote Black Whisper 5.5 PCP"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/348/PKgQvwLeJ3Jw3a1b7wq1j7yBFbjJcQcfMQtqWZXt.jpg",
                    categoriaG = "CALIBRE .22 MM",
                    nombreG = "Rifle Gamo Arrow PCP 5.5 Mira 4x32"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/396/descarga.jpeg",
                    categoriaG = "CALIBRE .25 Y .30 MM",
                    nombreG = "Rifle Gamo GX 250 6.35 PCP"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/397/rifle-airforce-condor-ss-precargado-spin-loc-tank-de-diabolos-calibre-25-635mm.jpg",
                    categoriaG = "CALIBRE .25 Y .30 MM",
                    nombreG = "Rifle Airforce Airguns Condor SS 25 PCP"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/365/tqVlUHiy1h2P57Okl2zwtf9YDe049tMiGeIHTaHx.jpg",
                    categoriaG = "CALIBRE .45 Y .50 MM",
                    nombreG = "Rifle Umarex Hammer 50 PCP"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/394/10452_500__1705679704.jpg",
                    categoriaG = "CALIBRE .45 Y .50 MM",
                    nombreG = "Rifle Seneca Big Bore Ligth Hunter 45"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/293/PK_62L_1DE4.jpg",
                    categoriaG = "SALVA",
                    nombreG = "Pistola Mendoza PK 62 Cañon Largo Muni Salva"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/292/PK_62C_CAMO_1DE5.jpg",
                    categoriaG = "SALVA",
                    nombreG = "Pistola Mendoza PK 62 Cañon Corto Muni Salva Camuflajeada"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/291/PK_62C_1DE5.jpg",
                    categoriaG = "SALVA",
                    nombreG = "Pistola Mendoza PK 62 Cañon Corto Muni Salva"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/290/DERRINGER_1DE2.jpg",
                    categoriaG = "SALVA",
                    nombreG = "Pistola Mendoza Derringer Muni Salva"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/302/BRODAX_1DE5.jpg",
                    categoriaG = "CO2",
                    nombreG = "Revolver Umarex Brodax"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/389/SNR_357_1DE3.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Revolver Crosman SNR 357"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/306/COLT_PYTHON_1DE6.jpg",
                    categoriaG = "CO2",
                    nombreG = "Revolver Colt Phyton Umarex"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/376/WhatsApp%20Image%202024-01-17%20at%205.05.24%20PM%20(1).jpeg",
                    categoriaG = "CO2",
                    nombreG = "Revolver Asg Dan Wesson Oro 357 CO2"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/322/XBG_1DE6.jpg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Umarex XBG"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/321/8NFGMFm5yVAOs3ufRdOardO5Od5cCpM4auJDLEIk.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Umarex SA10"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/317/MAKAROV_1DE6.jpg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Umarex Makarov"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/315/LEGENDS_M712_1DE5.jpg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Umarex Legends M712"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/304/COLT_DEFENDER_1DE5.jpg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Umarex Colt Defender"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/303/COLT_COMANDER_1DE7.jpg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Umarex Colt Commander"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/323/9XP_1DE4.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Umarex 9XP"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/314/HK_VP9_1DE5.jpg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Heckler & Koch VP9"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/315/fy7I5zWIT4wnoAhbBX8SDki0yd27Plt1lhwJrZFB.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Heckler & Koch USP"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/312/tqjxIlFzl6vP6oHkviwpTZplSTtFXFhdZ6ubZsQn.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Glock 19 Generación 3 Umarex"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/311/HI5rCNrvJIDParmJMTDHPM5e3EhR4wSgyZROxNlm.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Glock 17 Generación 4 Umarex"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/310/Ak2ZSLU3tbqCdFFrxi9j33HwN2gYsScu3c98zr8q.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Glock 17 Generación 3 Umarex"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/497/2oXjm4ZWkHpR8nv79Oqxs2eJR7JgJyQJ4OjCUeYy.jpg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Crosman PFM 16"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/386/NIGTH_STALKER_1DE4.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Crosman Nigth Stalker"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/383/MAKO_1DE4.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Crosman Mako"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/377/WhatsApp%20Image%202024-01-17%20at%206.06.47%20PM%20(1).jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Crosman Full Auto P1 CO2"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/371/WhatsApp%20Image%202024-01-17%20at%204.21.54%20PM.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Crosman C11"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/307/9zZUqHFiAAJ4QElKyM3tLTOtWLaYdqd7ZpDwSbLN.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Colt M45 Umarex"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/303/A6NZ0xPfqtdu9gU9KLtOCPloytJwyuFuuzW8rZlG.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Beretta PX4 Storm Umarex"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/302/MuLPvwsU1vaDCwODBwVy5oDXSTc7XQgapIDlUySc.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Beretta M92A1 Umarex"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/301/TxeL6uRI8FyRr1iPj4exgf46lvMQJnlCuBpsdS2N.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Beretta M84FS Umarex"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/product/299/0WVYb5Wq5aNWBWILB0Th0t19PgcbJ5FjbDNM1a7B.png",
                    categoriaG = "CO2",
                    nombreG = "Pistola Beretta Elite II Umarex"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/391/THUNDER_2DE2.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Asg Thunder 9 Pro"
                ),

                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/385/MODEL_75_1DE3.jpg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Asg Model 75"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/375/WhatsApp%20Image%202024-01-17%20at%204.52.07%20PM.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Asg CZ Shadow 2 CO2"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/374/WhatsApp%20Image%202024-01-17%20at%204.44.05%20PM.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Asg CZ P-09 CO2"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/372/WhatsApp%20Image%202024-01-17%20at%204.30.44%20PM.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Asg CZ 75 P-07"
                ),
                Galeria(
                    fotoGa = "https://safarindoor.com.mx/cache/large/products/370/WhatsApp%20Image%202024-01-17%20at%204.12.24%20PM.jpeg",
                    categoriaG = "CO2",
                    nombreG = "Pistola Asg BP9CC"
                )
            )
    }
}