package com.example.sanchesnparcial2_v2.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.sanchesnparcial2_v2.Galeria
import com.example.sanchesnparcial2_v2.Producto
import com.example.sanchesnparcial2_v2.R


class GaleriaAdapter (private val galeriaList: List<Galeria>, private val onClickListener: (Galeria) -> Unit) : RecyclerView.Adapter<GaleriaViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GaleriaViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return GaleriaViewHolder(layoutInflater.inflate(R.layout.item_galeria, parent, false))
    }

    override fun getItemCount(): Int = galeriaList.size

    override fun onBindViewHolder(holder: GaleriaViewHolder, position: Int) {
        val item = galeriaList[position]
        holder.render(item, onClickListener)
    }
}