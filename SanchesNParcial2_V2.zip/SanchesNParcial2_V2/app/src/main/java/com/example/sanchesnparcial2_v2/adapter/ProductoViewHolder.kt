package com.example.sanchesnparcial2_v2.adapter

import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.sanchesnparcial2_v2.Producto
import com.example.sanchesnparcial2_v2.R
import com.example.sanchesnparcial2_v2.databinding.ItemProductosBinding

class ProductoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    private val btnDetalles:Button=itemView.findViewById(R.id.btnDetalles)
    val binding = ItemProductosBinding.bind(view)

    fun render(productoModel: Producto, onClickListener: (Producto) -> Unit) {
        binding.tvNombre.text = productoModel.nombre
        binding.tvcategoria.text = productoModel.categoria
        binding.tvCodigo.text = productoModel.codigo
        binding.tvMarca.text = productoModel.marca
        binding.tvPresio.text= productoModel.precio.toString()

        Glide.with(binding.ivFoto.context).load(productoModel.foto).into(binding.ivFoto)
        itemView.setOnClickListener { onClickListener(productoModel) }

        btnDetalles.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(productoModel.detalles))
            itemView.context.startActivity(intent)
        }
    }
}
