package com.example.sanchesnparcial2_v2.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.sanchesnparcial2_v2.Galeria

import com.example.sanchesnparcial2_v2.databinding.ItemGaleriaBinding

class GaleriaViewHolder(view:View) : RecyclerView.ViewHolder(view) {
    val binding = ItemGaleriaBinding.bind(view)

    fun render(galeriaModel: Galeria, onClickListener: (Galeria) -> Unit){
        binding.tvCategoriaG.text = galeriaModel.categoriaG

        Glide.with(binding.ivFotoG.context).load(galeriaModel.fotoGa).into(binding.ivFotoG)
        itemView.setOnClickListener { onClickListener(galeriaModel) }
    }
}