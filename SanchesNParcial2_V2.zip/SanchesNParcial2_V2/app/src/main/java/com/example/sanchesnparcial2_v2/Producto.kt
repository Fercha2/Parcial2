package com.example.sanchesnparcial2_v2

data class Producto(
    val nombre: String,
    val foto: String,
    val categoria: String,
    val codigo: String,
    val marca: String,
    val precio: Double,
    val detalles: String,
)
