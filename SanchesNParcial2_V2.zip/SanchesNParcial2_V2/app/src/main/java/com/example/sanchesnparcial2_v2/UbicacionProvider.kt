package com.example.sanchesnparcial2_v2

class UbicacionProvider {
    companion object{
        val ubicacionList: List<Ubicacion>
            get() = listOf(
                Ubicacion(
                    sucursal = "Suc. Aguascalientes",
                    domicilio = "Domicilio: Quinta avenida Num. 404, Colonia Las Americas \nC.P. 20230 Aguascalientes, Ags",
                    horario = "Horario: Lunes a Sábado 10:30 a.m. 9:00 p.m. Domingo 11:30 a.m. 6:00 p.m.",
                    telefono = "Telefono: 4492938757",
                    email = "E-mail: ventasweb@safarindoor.com.mx",
                    mapa = "https://www.google.com.mx/maps/place/Safari+Indoor/@21.867883,-102.297611,17z/data=!3m1!4b1!4m6!3m5!1s0x8429edd507e034dd:0xf9658b89c02ae86f!8m2!3d21.867883!4d-102.297611!16s%2Fg%2F11bc7pr6qh?entry=ttu"
                ),
                Ubicacion(
                    sucursal = "Suc. Centro AGS",
                    domicilio = "Domicilio: 5 de mayo Num. 542 Colonia Centro \nC.P. 20000 Aguascalientes, Ags.",
                    horario = "Horario: Lunes a Sábado 9:00 a.m. 7:00 p.m. Domingo/NAVIDEÑOS 10:00 a.m. 6:00 p.m.",
                    telefono = "Telefono: 4499180228",
                    email = "E-mail: ventasweb@safarindoor.com.mx",
                    mapa = "https://www.google.com.mx/maps/place/SAFARI+INDOOR+CENTRO+AGS/@21.8869706,-102.2970104,17z/data=!3m1!4b1!4m6!3m5!1s0x8429ee63c5635713:0xa4d139d1b4a06a0d!8m2!3d21.8869706!4d-102.2970104!16s%2Fg%2F11b6skyzz6?entry=ttu"
                ),
                Ubicacion(
                    sucursal = "Suc. Guadalajara",
                    domicilio = "Domicilio: Av. Ávila camacho Num. 2288 Colonia Jardines del Country \nC.P. 44210 Guadalajara, Jalisco",
                    horario = "Horario: Lunes a Sábado 10:30 a.m. 9:00 p.m. Domingo 11:30 a.m. 6:00 p.m.",
                    telefono = "Telefono: 3336854494",
                    email = "E-mail: ventasweb@safarindoor.com.mx",
                    mapa = "https://www.google.com.mx/maps/place/Safari+indoor+Gdl/@20.7083218,-103.3709377,17z/data=!3m1!4b1!4m6!3m5!1s0x8428af0d315397a3:0x8dfe4ec821209861!8m2!3d20.7083168!4d-103.3683628!16s%2Fg%2F11nxc5nzsb?entry=tts&shorturl=1"
                )
            )
    }
}