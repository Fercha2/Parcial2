package com.example.sanchesnparcial2_v2

class ProductoProvider {
    companion object {
        val productoLst: List<Producto>
            get() = listOf(
                Producto(
                    nombre = "Rifle Hatsan Zada 5.5 Mira 4x32",
                    foto = "https://safarindoor.com.mx/cache/large/products/542/PY-5382_Hatsan-Zada_1688677863.jpg",
                    categoria = "Categoria: RESORTE",
                    codigo = "Codigo: F6456",
                    marca = "Marca: HATSAN",
                    precio = 3900.00,
                    detalles = "https://safarindoor.com.mx/rifle-zada-55-mira-4x32"
                ),
                Producto(
                    nombre = "Rifle Gamo Carbon Storm 5.5 Mira 3-9x40",
                    foto = "https://safarindoor.com.mx/cache/large/products/331/CARBON_STORM_1DE3.jpg",
                    categoria = "Categoria: RESORTE",
                    codigo = "Codigo: F6479",
                    marca = "Marca: GAMO",
                    precio = 5950.00,
                    detalles = "https://safarindoor.com.mx/carbon-storm-55"
                ),
                Producto(
                    nombre = "Rifle Gamo Bone Collector 5.5 mira 3-9x40",
                    foto = "https://safarindoor.com.mx/cache/large/products/330/BONE_COLLECTOR_1DE5.jpg",
                    categoria = "Categoria: RESORTE",
                    codigo = "Codigo: F1775",
                    marca = "Marca: GAMO",
                    precio = 7800.00,
                    detalles = "https://safarindoor.com.mx/bone-collector-55"
                ),
                Producto(
                    nombre = "Rifle Umarex Syrix 4.5 Mira 4x32",
                    foto = "https://safarindoor.com.mx/cache/large/products/359/SYRIX_177_1DE7.jpg",
                    categoria = "Categoria: NITRO PISTÓN",
                    codigo = "Codigo: F9905",
                    marca = "Marca: UMAREX",
                    precio = 3350.00,
                    detalles = "https://safarindoor.com.mx/rifle-syrix-45-mira-4x32"
                ),
                Producto(
                    nombre = "Rifle Gamo Black Fusion 5.5 Mira 3-9x40",
                    foto = "https://safarindoor.com.mx/cache/large/products/329/BLACK_FUSION_1DE2.jpg",
                    categoria = "Categoria: NITRO PISTÓN",
                    codigo = "Codigo: F3075",
                    marca = "Marca: GAMO",
                    precio = 8950.00,
                    detalles = "https://safarindoor.com.mx/black-fusion-55"
                ),
                Producto(
                    nombre = "Rifle Gamo Gmagnum 1250 5.5 Mira 3-9x40",
                    foto = "https://safarindoor.com.mx/cache/large/products/336/G-MAGNUM-IGT-MACH-1.jpg",
                    categoria = "Categoria: NITRO PISTÓN",
                    codigo = "Codigo: F5181",
                    marca = "Marca: GAMO",
                    precio = 9400.00,
                    detalles = "https://safarindoor.com.mx/gmagnum-1250-55"
                ),
                Producto(
                    nombre = "Subfusil Umarex HK 416 Electrica",
                    foto = "https://safarindoor.com.mx/cache/large/product/369/Jd3oXsHd7ugh0OGTzMD2X5PuzpOOsiq35tdjUK9U.jpg",
                    categoria = "Categoria: CO2 E INFANTILES",
                    codigo = "Codigo: F6280",
                    marca = "Marca: UMAREX",
                    precio = 4200.00,
                    detalles = "https://safarindoor.com.mx/subfusil-hk-416-electrica"
                ),
                Producto(
                    nombre = "Subfusil Crosman DPMS SBR CO2",
                    foto = "https://safarindoor.com.mx/cache/large/products/532/Crosman-DPMS-M4-SBR-Semi-Auto-CO2-Air-Rifle-Gallery-1.jpg",
                    categoria = "Categoria: CO2 E INFANTILES",
                    codigo = "Codigo: F6293",
                    marca = "Marca: CROSMAN",
                    precio = 8600.00,
                    detalles = "https://safarindoor.com.mx/subfusil-dpms-sbr-co2"
                ),
                Producto(
                    nombre = "Subfusil Crosman AK01 CO2",
                    foto = "https://safarindoor.com.mx/cache/large/product/535/KENFwv1jLPWqAFhoZMY5jOX30sniutsI8dxbDaFm.jpg",
                    categoria = "Categoria: CO2 E INFANTILES",
                    codigo = "Codigo: F3004",
                    marca = "Marca: CROSMAN",
                    precio = 6700.00,
                    detalles = "https://safarindoor.com.mx/subfusil-ak01-co2"
                ),
                Producto(
                    nombre = "Revolver Colt Phyton Umarex",
                    foto = "https://safarindoor.com.mx/cache/large/product/308/ocvTiZpvYN9xjKRxoZpWp0fw3Ckah5j0l3OyKAvV.png",
                    categoria = "Categoria: CO2",
                    codigo = "Codigo: F0572",
                    marca = "Marca: UMAREX",
                    precio = 1990.00,
                    detalles = "https://safarindoor.com.mx/revolver-colt-phyton-"
                ),
                Producto(
                    nombre = "Pistola Umarex Colt Commander",
                    foto = "https://safarindoor.com.mx/cache/large/product/305/ChLfY9jTQuOS0GAWL5EqFCqsjpzjvUS19rLaIrSj.png",
                    categoria = "Categoria: CO2",
                    codigo = "Codigo: F0574",
                    marca = "Marca: UMAREX",
                    precio = 5300.00,
                    detalles = "https://safarindoor.com.mx/pistola-colt-commander-"
                ),
                Producto(
                    nombre = "Pistola Heckler & Koch USP",
                    foto = "https://safarindoor.com.mx/cache/large/products/313/HK_USP_1DE5.jpg",
                    categoria = "Categoria: CO2",
                    codigo = "Codigo: F0571",
                    marca = "Marca: UMAREX",
                    precio = 2300.00,
                    detalles = "https://safarindoor.com.mx/heckler-koch-hk-usp"
                ),
                Producto(
                    nombre = "Pistola Colt M45 Umarex",
                    foto = "https://safarindoor.com.mx/cache/large/product/307/9zZUqHFiAAJ4QElKyM3tLTOtWLaYdqd7ZpDwSbLN.png",
                    categoria = "Categoria: CO2",
                    codigo = "Codigo: F6235",
                    marca = "Marca: UMAREX",
                    precio = 3200.00,
                    detalles = "https://safarindoor.com.mx/pistola-colt-m45-"
                ),
                Producto(
                    nombre = "Pistola Heckler & Koch USP",
                    foto = "https://safarindoor.com.mx/cache/large/product/395/RztnhvtlpJb48fG1YajEZNZ4sL7sld8aCCWPAFMJ.jpg",
                    categoria = "Categoria: CALIBRE .22 MM",
                    codigo = "Codigo: RPCP8",
                    marca = "Marca: SIG SAUER",
                    precio = 17900.00,
                    detalles = "https://safarindoor.com.mx/rifle-sig-sauer-mxc-virtus-pcp-55"
                ),
                Producto(
                    nombre = "Rifle Snowpeak PR900 5.5 PCP",
                    foto = "https://safarindoor.com.mx/cache/large/products/398/prre.jpg",
                    categoria = "Categoria: CALIBRE .22 MM",
                    codigo = "Codigo: PCP13",
                    marca = "Marca: SNOWPEAK",
                    precio = 6900.00,
                    detalles = "https://safarindoor.com.mx/rifle-pr900-55-pcp"
                ),
                Producto(
                    nombre = "Rifle Gamo GX 250 6.35 PCP",
                    foto = "https://safarindoor.com.mx/cache/large/products/396/descarga.jpeg",
                    categoria = "Categoria: CALIBRE .25 Y .30 MM",
                    codigo = "Codigo: PCP11",
                    marca = "Marca: GAMO",
                    precio = 17900.00,
                    detalles = "https://safarindoor.com.mx/rifle-gx-250-635-pcp"
                ),
                Producto(
                    nombre = "Rifle Airforce Airguns Condor SS 25 PCP",
                    foto = "https://safarindoor.com.mx/cache/large/products/397/rifle-airforce-condor-ss-precargado-spin-loc-tank-de-diabolos-calibre-25-635mm.jpg",
                    categoria = "Categoria: CALIBRE .25 Y .30 MM",
                    codigo = "Codigo: PCP12",
                    marca = "Marca: AIRFORCE AIRGUNS",
                    precio = 25500.00,
                    detalles = "https://safarindoor.com.mx/rifle-condor-ss-25-pcp"
                ),
                Producto(
                    nombre = "Rifle Umarex Hammer 50 PCP",
                    foto = "https://safarindoor.com.mx/cache/large/products/363/HAMMER_50_PCP_1DE9.jpg",
                    categoria = "Categoria: CALIBRE .45 Y .50 MM",
                    codigo = "Codigo: RPCP6",
                    marca = "Marca: UMAREX",
                    precio = 32200.00,
                    detalles = "https://safarindoor.com.mx/rifle-hammer-50-pcp"
                ),
                Producto(
                    nombre = "Rifle Seneca Big Bore Ligth Hunter 45",
                    foto = "https://safarindoor.com.mx/cache/large/products/394/10452_500__1705679704.jpg",
                    categoria = "Categoria: CALIBRE .45 Y .50 MM",
                    codigo = "Codigo: PCP9",
                    marca = "Marca: SENECA",
                    precio = 32500.00,
                    detalles = "https://safarindoor.com.mx/rifle-big-bore-ligth-hunter-45"
                )
            )
    }
}
