package com.example.sanchesnparcial2_v2

data class Galeria (
    val fotoGa: String,
    val categoriaG:String,
    val nombreG: String
)