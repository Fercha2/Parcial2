package com.example.sanchesnparcial2_v2.adapter

import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.example.sanchesnparcial2_v2.Ubicacion
import com.example.sanchesnparcial2_v2.R
import com.example.sanchesnparcial2_v2.databinding.ItemGaleriaBinding
import com.example.sanchesnparcial2_v2.databinding.ItemUbiBinding

class UbicacionViewHolder(view:View):RecyclerView.ViewHolder(view) {

    private val btnMapa: Button=itemView.findViewById(R.id.btnMapa)
    val binding = ItemUbiBinding.bind(view)

    fun render(ubicacionModel: Ubicacion, onClickListener:(Ubicacion)->Unit){
        binding.tvSucursal.text = ubicacionModel.sucursal
        binding.tvDomicilio.text = ubicacionModel.domicilio
        binding.tvHorario.text= ubicacionModel.horario
        binding.tvTelefono.text=ubicacionModel.telefono
        binding.tvEmail.text=ubicacionModel.email

        btnMapa.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(ubicacionModel.mapa))
            itemView.context.startActivity(intent)
        }

    }
}