package com.example.sanchesnparcial2_v2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Pantalla2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla2)
    }

    fun pasarProductos(view: View) {
        val intent2 = Intent(this, MainProductos::class.java)
        startActivity(intent2)
    }

    fun pasarInicio(view: View) {
        val intent3 = Intent(this, MainActivity::class.java)
        startActivity(intent3)
    }

    fun pasarGaleria(view: View) {
        val intent4 = Intent(this, MainGaleria::class.java)
        startActivity(intent4)
    }

    fun pasarUbi(view: View) {
        val intent5 = Intent(this, MainUbicacion::class.java)
        startActivity(intent5)
    }

    fun salir(view: View){
        finishAffinity()
    }
}
