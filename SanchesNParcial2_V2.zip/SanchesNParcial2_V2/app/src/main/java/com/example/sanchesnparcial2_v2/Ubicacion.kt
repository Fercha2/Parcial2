package com.example.sanchesnparcial2_v2

data class Ubicacion (
    val sucursal:String,
    val domicilio:String,
    val horario:String,
    val telefono:String,
    val email:String,
    val mapa:String
)