package com.example.sanchesnparcial2_v2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sanchesnparcial2_v2.adapter.UbicacionAdapter
import com.example.sanchesnparcial2_v2.databinding.ActivityMainUbicacionBinding

class MainUbicacion : AppCompatActivity() {

    private lateinit var binding: ActivityMainUbicacionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainUbicacionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initRecyclerView()
    }

    private fun initRecyclerView(){
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerUbi)
        val manager = LinearLayoutManager(this)
        recyclerView.layoutManager=manager

        recyclerView.adapter=UbicacionAdapter(UbicacionProvider.ubicacionList){
            onItemSelected(it)
        }
    }

    private fun onItemSelected(ubicacion:Ubicacion){
        Toast.makeText(this,ubicacion.sucursal,Toast.LENGTH_SHORT).show()
    }
}